﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using ABC.Models;

namespace ABC.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
      
        ABCDatabaseEntities1 db = new ABCDatabaseEntities1();
        //
        // GET: /Account/
        [AllowAnonymous]
        public ActionResult Login()
        {
            Session["role"] = "Guest";
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult Login(Customer customer, string ReturnUrl)
        {
            if (ModelState.IsValid)
            {
                Customer ValidUser = db.Customers.Where(c => c.Email == customer.Email && c.Password ==
                 customer.Password).FirstOrDefault();
                if (ValidUser != null)
                {
                    FormsAuthentication.SetAuthCookie(ValidUser.First_Name, false);
                    if (Url.IsLocalUrl(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        Session["role"] = "Customer";
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Invalid user, try again");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        
        [AllowAnonymous]
        public ActionResult AdminLogin()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult AdminLogin(Admin admin, string ReturnUrl)
        {
            if (ModelState.IsValid)
            {
                Admin ValidUser = db.Admins.Where(a => a.Email == admin.Email && a.Password ==
                 admin.Password).FirstOrDefault();
                
                if (ValidUser != null)
                {
                    FormsAuthentication.SetAuthCookie(ValidUser.First_Name, false);
                    if (Url.IsLocalUrl(ReturnUrl))
                    {
                        return Redirect(ReturnUrl);
                    }
                    else
                    {
                        Session["role"] = "Admin";
                        return RedirectToAction("index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Invalid user, try again");
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        [AllowAnonymous]
        public ActionResult createAccount()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult createAccount(Customer c)
        {
            db.Customers.Add(c);
            db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
        public ActionResult createAccountAd()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult createAccountAd(Admin ad)
        {
            db.Admins.Add(ad);
            db.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}